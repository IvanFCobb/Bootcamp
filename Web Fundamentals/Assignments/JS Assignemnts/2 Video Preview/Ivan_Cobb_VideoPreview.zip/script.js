console.log("page loaded...");

function play(element){
    element.innerText = "play()"
}

function pause(element){
    element.innerText = "pause()"
}